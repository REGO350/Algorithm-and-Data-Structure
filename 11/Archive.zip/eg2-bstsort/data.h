void printDataArray(int *d, int n, char *msg);
void generateRandomData(int *a, int n);